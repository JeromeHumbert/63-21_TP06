import java.util.*;

public class Test {
    private static ArrayList<Livre> livres = new ArrayList<>();
    private static HashMap<String, HashSet<Recette>> planning = new HashMap<>();
    private static final int NB_JOURS_PLANNING = 7;
    private static String[] jours = {"Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"};

    public static void chargerData(String path){
       // A compléter
    }

    public static void genererPlanning(){
        // A compléter
    }

    public static void afficherPlanning(){
        // A compléter
    }

    public static void afficherLivres(){
        // A compléter
    }

    public static void rechercheRecette(Recette r){
        // A compléter
    }

    public static void rechercheRecettePlanning(Recette r){
        // A compléter
    }

    public static void main(String[] args){
        String localDir = System.getProperty("user.dir");
        chargerData(localDir + "\\src\\livre1.csv");
        chargerData(localDir + "\\src\\livre2.csv");
        afficherLivres();
        genererPlanning();
        afficherPlanning();
        System.out.println("");
        rechercheRecette(new Recette("Jaret de porc",10,2,60));
        rechercheRecette(new Recette("Jaret de boeuf",10,2,60));
        rechercheRecettePlanning(new Recette("Jaret de porc",10,2,60));
    }
}
