import java.util.Objects;

public class Recette {

}
